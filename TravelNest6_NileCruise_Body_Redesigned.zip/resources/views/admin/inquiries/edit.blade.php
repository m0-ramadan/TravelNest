@include('admin.i18n.locale')
@extends('admin.layout.master')

@section('title', admin_t('تعديل استفسار'))

@section('css')
    <style>
        :root {
            --primary-color: #696cff;
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --dark-bg: #1e1e2d;
            --dark-card: #2b3b4c;
        }

        body {
            font-family: "Cairo", sans-serif !important;
            background: var(--dark-bg);
            color: #fff;
        }

        .main-card {
            background: var(--dark-card);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0, 0, 0, .3);
            border: 1px solid rgba(255, 255, 255, .1);
        }

        .main-header {
            background: var(--primary-gradient);
            color: #fff;
            padding: 25px 30px;
        }

        .form-body {
            padding: 30px;
        }

        .section-title {
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, .1);
            padding-bottom: 10px;
        }

        .form-control,
        .form-select,
        textarea {
            background: rgba(255, 255, 255, .05);
            border: 1px solid rgba(255, 255, 255, .1);
            color: #fff;
            border-radius: 10px;
            min-height: 46px;
        }

        .form-control:focus,
        .form-select:focus,
        textarea:focus {
            background: rgba(255, 255, 255, .08);
            color: #fff;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 .25rem rgba(105, 108, 255, .25);
        }
    </style>
@endsection

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">الرئيسية</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.inquiries.index') }}">الاستفسارات</a></li>
                <li class="breadcrumb-item active">تعديل استفسار</li>
            </ol>
        </nav>

        <div class="main-card">
            <div class="main-header d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0">تعديل الاستفسار</h5>
                    <small class="opacity-75">{{ $inquiry->subject ?? '' }}</small>
                </div>
                <a href="{{ route('admin.inquiries.index') }}" class="btn btn-light">رجوع</a>
            </div>

            <div class="form-body">
                <form action="{{ route('admin.inquiries.update', $inquiry) }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="section-title">بيانات الاستفسار</div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" name="name" class="form-control"
                                value="{{ old('name', $inquiry->name) }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" name="email" class="form-control"
                                value="{{ old('email', $inquiry->email) }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">الهاتف</label>
                            <input type="text" name="phone" class="form-control"
                                value="{{ old('phone', $inquiry->phone) }}">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">الباقة</label>
                            <select name="package_id" class="form-select">
                                <option value="">اختر الباقة</option>
                                @foreach ($packages ?? collect() as $package)
                                    <option value="{{ $package->id }}"
                                        {{ old('package_id', $inquiry->package_id) == $package->id ? 'selected' : '' }}>
                                        {{ $package->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">الموضوع</label>
                            <input type="text" name="subject" class="form-control"
                                value="{{ old('subject', $inquiry->subject) }}">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">تاريخ السفر</label>
                            <input type="date" name="travel_date" class="form-control"
                                value="{{ old('travel_date', optional($inquiry->travel_date)->format('Y-m-d')) }}">
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label">عدد الأفراد</label>
                            <input type="number" name="travellers_count" class="form-control"
                                value="{{ old('travellers_count', $inquiry->travellers_count) }}">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label">الرسالة</label>
                            <textarea name="message" class="form-control" rows="6">{{ old('message', $inquiry->message) }}</textarea>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">الحالة</label>
                            <select name="status" class="form-select">
                                <option value="new" {{ old('status', $inquiry->status) == 'new' ? 'selected' : '' }}>new
                                </option>
                                <option value="contacted"
                                    {{ old('status', $inquiry->status) == 'contacted' ? 'selected' : '' }}>contacted
                                </option>
                                <option value="converted"
                                    {{ old('status', $inquiry->status) == 'converted' ? 'selected' : '' }}>converted
                                </option>
                                <option value="closed" {{ old('status', $inquiry->status) == 'closed' ? 'selected' : '' }}>
                                    closed</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex gap-2 mt-4">
                        <button class="btn btn-primary" type="submit">حفظ</button>
                        <a href="{{ route('admin.inquiries.index') }}" class="btn btn-secondary">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
