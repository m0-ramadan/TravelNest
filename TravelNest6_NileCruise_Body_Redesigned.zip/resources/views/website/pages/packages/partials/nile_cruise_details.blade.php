@if($package->package_type === 'nile_cruise')
    @php
        $ncDetail = $package->nileCruiseDetail;
        $ncSchedules = $package->nileCruiseSchedules?->where('is_active', true) ?? collect();
        $ncCabins = $package->nileCruiseCabins ?? collect();
        $ncLegacyAddons = $package->nileCruiseAddons?->where('is_active', true) ?? collect();
        $ncAddons = isset($addons) && $addons->isNotEmpty() ? $addons : $ncLegacyAddons;
        $ncOperatingDays = isset($operatingDays) && $operatingDays->isNotEmpty() ? $operatingDays : collect((array) ($ncDetail?->operating_days ?? []));
        $ncLanguages = isset($onTourLanguages) && $onTourLanguages->isNotEmpty() ? $onTourLanguages : collect((array) ($ncDetail?->on_tour_languages ?? []));
        $ncWhatToBring = isset($whatToBring) && $whatToBring->isNotEmpty() ? $whatToBring : collect((array) ($ncDetail?->what_to_bring ?? []));
        $ncVideos = isset($promotionalVideos) && $promotionalVideos->isNotEmpty() ? $promotionalVideos : collect((array) ($ncDetail?->promotional_videos ?? []));
        $ncDepositPolicy = $package->deposit_policy ?: ($ncDetail?->deposit_policy ?? null);
        $ncDepositType = $package->deposit_type ?: ($ncDetail?->deposit_type ?? null);
        $ncDepositValue = $package->deposit_value ?? ($ncDetail?->deposit_value ?? null);
        $ncCruise = $package->cruise;
        $ncDurations = $package->nileCruiseDurations?->where('is_active', true)->values() ?? collect();
        $ncRoute = $package->cities?->sortBy(fn($city) => $city->pivot?->stop_order ?? 0)->values() ?? collect();
        $hasNcExtendedData = $ncDetail || $ncCruise || $ncSchedules->isNotEmpty() || $ncCabins->isNotEmpty() || $ncAddons->isNotEmpty() || $ncDurations->isNotEmpty();
    @endphp

    @if($hasNcExtendedData)
        <style>
            .nc-schedule-grid,.nc-cabin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
            .nc-schedule,.nc-cabin{border:1px solid rgba(28, 50, 92, 0.12);border-radius:14px;padding:18px;background:#ffffff;box-shadow:0 4px 15px rgba(0,0,0,0.03)}
            .nc-cabin-meta{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
            .nc-pill{display:inline-flex;padding:6px 12px;border-radius:999px;background:var(--pearl-luxury, #faf8f3);color:var(--primary-navy, #1c325c);font-size:0.82rem;font-weight:600;border:1px solid rgba(197, 149, 91, 0.25)}
            .nc-duration-tabs{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px}
            .nc-duration-tab{border:1.5px solid var(--rich-gold, #c5955b);background:#ffffff;color:var(--primary-navy, #1c325c);padding:10px 18px;border-radius:999px;cursor:pointer;font-weight:700;font-size:0.92rem;transition:all 0.25s ease}
            .nc-duration-tab.active,.nc-duration-tab:hover{background:var(--gradient-gold, #c5955b);color:var(--primary-navy, #1c325c);border-color:var(--rich-gold, #c5955b);box-shadow:0 4px 12px rgba(197, 149, 91, 0.3)}
            .nc-duration-panel{display:none}
            .nc-duration-panel.active{display:block}
            .nc-day{border:1px solid rgba(28, 50, 92, 0.12);border-radius:14px;margin-bottom:14px;background:#ffffff;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.02)}
            .nc-day summary{cursor:pointer;padding:16px 20px;font-weight:700;color:var(--primary-navy, #1c325c);font-size:1.05rem}
            .nc-day-body{padding:0 20px 20px}
            .nc-activity{padding:12px 0;border-top:1px solid rgba(28, 50, 92, 0.08)}
            .nc-addon-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}
            .nc-addon{border:1px solid rgba(28, 50, 92, 0.12);border-radius:14px;padding:16px;background:#ffffff}
            .nc-cabin img{width:100%;height:200px;object-fit:cover;border-radius:10px;margin-bottom:14px}
            .nc-fact-sheet{display:inline-flex;align-items:center;gap:8px}

            /* Theme Integration & Dark Mode Support */
            html[data-theme='dark'] .nc-schedule,
            html[data-theme='dark'] .nc-cabin,
            html[data-theme='dark'] .nc-day,
            html[data-theme='dark'] .nc-addon {
                background: #1a233a !important;
                border-color: rgba(255, 255, 255, 0.12) !important;
                color: #e2e8f0 !important;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important;
            }
            html[data-theme='dark'] .nc-day summary { color: #ffffff !important; }
            html[data-theme='dark'] .nc-pill { background: rgba(197, 149, 91, 0.18) !important; color: #c5955b !important; border-color: rgba(197, 149, 91, 0.3) !important; }
            html[data-theme='dark'] .nc-duration-tab { background: #151d30 !important; color: #e2e8f0 !important; border-color: rgba(197, 149, 91, 0.4) !important; }
            html[data-theme='dark'] .nc-duration-tab.active { background: var(--gradient-gold, #c5955b) !important; color: #1c325c !important; }

            @media(max-width:900px){.nc-schedule-grid,.nc-cabin-grid{grid-template-columns:1fr}.nc-addon-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
            @media(max-width:520px){.nc-addon-grid{grid-template-columns:1fr}}
        </style>

        {{-- 1. Nile Cruise Details Section --}}
        @include('website.pages.packages.partials.nile_cruise.details_grid')

        {{-- 2. Schedule, Cabins & Route Section --}}
        @include('website.pages.packages.partials.nile_cruise.schedule_cabins_route')

        {{-- 3. Itinerary Section --}}
        @include('website.pages.packages.partials.nile_cruise.itinerary')

        {{-- 4. Includes / Excludes Section --}}
        @include('website.pages.packages.partials.nile_cruise.includes_excludes')

        {{-- 5. Pricing & Packages Section --}}
        @include('website.pages.packages.partials.nile_cruise.pricing')

        {{-- 6. Cruise Facilities Section --}}
        @include('website.pages.packages.partials.nile_cruise.facilities')

        {{-- 7. Important Information & Policies Section --}}
        @include('website.pages.packages.partials.nile_cruise.important_info')

        <script>
            document.addEventListener('DOMContentLoaded', function(){
                document.querySelectorAll('.nc-duration-tab').forEach(function(btn){
                    btn.addEventListener('click', function(){
                        const scope = btn.closest('#cruise-itineraries');
                        if (scope) {
                            scope.querySelectorAll('.nc-duration-tab').forEach(x => x.classList.remove('active'));
                            scope.querySelectorAll('.nc-duration-panel').forEach(x => x.classList.remove('active'));
                            btn.classList.add('active');
                            const target = document.getElementById(btn.dataset.ncDurationTarget);
                            if (target) target.classList.add('active');
                        }
                    });
                });
            });
        </script>
    @endif
@endif
