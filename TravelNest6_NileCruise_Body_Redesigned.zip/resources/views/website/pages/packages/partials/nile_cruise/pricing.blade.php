@php
    $ncDurations = $package->nileCruiseDurations?->where('is_active', true)->values() ?? collect();
    $ncLegacyAddons = $package->nileCruiseAddons?->where('is_active', true) ?? collect();
    $ncAddons = isset($addons) && $addons->isNotEmpty() ? $addons : $ncLegacyAddons;
    $hasSeasonPrices = $ncDurations->contains(fn($d) => $d->seasonPrices->where('is_active', true)->isNotEmpty());
@endphp

@if($hasSeasonPrices || $ncAddons->isNotEmpty())
    <section class="content-section" id="pricing-packages">
        <h2 class="section-header">{{ __('Pricing & Packages') }}</h2>
        <p class="section-subtitle">{{ __('Choose your preferred duration and season. Prices are shown using the cruise pricing configured for each cabin or occupancy option.') }}</p>

        @if($hasSeasonPrices)
            <div class="pricing-duration-accordions">
                @foreach($ncDurations as $durationIndex => $duration)
                    @php
                        $activeSeasons = $duration->seasonPrices->where('is_active', true)->values();
                        $priceLabels = $activeSeasons
                            ->flatMap(fn($season) => $season->items)
                            ->map(function($item){
                                return trim((string) ($item->cabin?->name ?: ($item->display_label ?: ucfirst((string)$item->occupancy_type))));
                            })
                            ->filter()->unique()->values();
                    @endphp
                    @if($activeSeasons->isNotEmpty())
                        <details class="nc-price-duration" {{ $durationIndex === 0 ? 'open' : '' }}>
                            <summary>
                                <span class="nc-price-duration-name">{{ $duration->title }}</span>
                                <span class="nc-price-seasons">{{ trans_choice(':count Season|:count Seasons', $activeSeasons->count(), ['count' => $activeSeasons->count()]) }}</span>
                                <span class="nc-price-from">
                                    @if($duration->start_from_price)
                                        {{ __('From') }}: {{ $duration->currency?->symbol ?: ($package->currency?->symbol ?: '$') }}{{ number_format((float)$duration->start_from_price, 0) }}
                                    @else
                                        {{ __('View Prices') }}
                                    @endif
                                </span>
                            </summary>
                            <div class="nc-price-body">
                                <table class="nc-price-matrix">
                                    <thead>
                                        <tr>
                                            <th>{{ __('Season') }}</th>
                                            <th>{{ __('From') }}</th>
                                            <th>{{ __('To') }}</th>
                                            @foreach($priceLabels as $label)
                                                <th>{{ $label }}</th>
                                            @endforeach
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($activeSeasons as $season)
                                            @php
                                                $itemsByLabel = $season->items->keyBy(function($item){
                                                    return trim((string) ($item->cabin?->name ?: ($item->display_label ?: ucfirst((string)$item->occupancy_type))));
                                                });
                                            @endphp
                                            <tr>
                                                <td>{{ $season->display_season_name ?: __('Season') }}</td>
                                                <td>{{ $season->date_from?->format('d M Y') ?: '—' }}</td>
                                                <td>{{ $season->date_to?->format('d M Y') ?: '—' }}</td>
                                                @foreach($priceLabels as $label)
                                                    @php $priceItem = $itemsByLabel->get($label); @endphp
                                                    <td>
                                                        @if($priceItem)
                                                            <span class="price-value">{{ $season->currency?->symbol ?: ($package->currency?->symbol ?: '$') }}{{ number_format((float)$priceItem->price, 0) }}</span>
                                                        @else
                                                            <span class="text-muted">—</span>
                                                        @endif
                                                    </td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </details>
                    @endif
                @endforeach
            </div>
        @endif

        @if($ncAddons->isNotEmpty())
            <div class="mt-4 pt-3 border-top" style="border-color:rgba(28,50,92,.08)!important;">
                <h3 class="nc-subsection-title" style="border-bottom:0;margin-bottom:12px;">
                    <span class="title-left"><i class="la la-plus-circle"></i>{{ __('Optional Cruise Excursions & Add-ons') }}</span>
                </h3>
                <div class="nc-addon-grid">
                    @foreach($ncAddons as $addon)
                        <div class="nc-addon">
                            <strong class="d-block" style="color:#1c325c;font-size:.9rem;">{{ $addon->title ?? $addon->name ?? __('Add-on') }}</strong>
                            @if($addon->description)<p class="small text-muted mb-2 mt-1">{{ $addon->description }}</p>@endif
                            <strong style="color:#c5955b;font-size:1rem;">{{ $addon->currency?->symbol ?: ($package->currency?->symbol ?: '$') }}{{ number_format((float)$addon->price, 2) }}</strong>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </section>
@endif
