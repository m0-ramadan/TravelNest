@php
    $ncDetail = $package->nileCruiseDetail;
    $ncWhatToBring = isset($whatToBring) && $whatToBring->isNotEmpty() ? $whatToBring : collect((array) ($ncDetail?->what_to_bring ?? []));
    $hasInclusions = !empty($inclusions) && count($inclusions) > 0;
    $hasExclusions = !empty($exclusions) && count($exclusions) > 0;
@endphp

@if($hasInclusions || $hasExclusions || $ncWhatToBring->isNotEmpty())
    <section class="content-section" id="includes-excludes">
        <h2 class="section-header">{{ __('What\'s Included & Excluded') }}</h2>
        <div class="row g-3">
            @if($hasInclusions)
                <div class="{{ $hasExclusions ? 'col-md-6' : 'col-12' }}">
                    <div class="nc-list-card">
                        <h3 class="nc-list-title"><i class="la la-check-circle ok"></i>{{ __('What\'s Included') }}</h3>
                        <ul class="nc-clean-list">
                            @foreach($inclusions as $inc)
                                <li><i class="la la-check-circle"></i><span>{{ is_array($inc) ? ($inc['title'] ?? '') : $inc }}</span></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif

            @if($hasExclusions)
                <div class="{{ $hasInclusions ? 'col-md-6' : 'col-12' }}">
                    <div class="nc-list-card">
                        <h3 class="nc-list-title"><i class="la la-times-circle no"></i>{{ __('What\'s Excluded') }}</h3>
                        <ul class="nc-clean-list">
                            @foreach($exclusions as $exc)
                                <li><i class="la la-times-circle"></i><span>{{ is_array($exc) ? ($exc['title'] ?? '') : $exc }}</span></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif

            @if($ncWhatToBring->isNotEmpty())
                <div class="col-12">
                    <div class="nc-list-card" style="background:#fbfcfe;">
                        <h3 class="nc-list-title"><i class="la la-suitcase-rolling ok"></i>{{ __('What to Bring') }}</h3>
                        <div class="d-flex flex-wrap gap-2">
                            @foreach($ncWhatToBring as $bringItem)
                                <span class="nc-pill"><i class="la la-check me-1" style="color:#c5955b"></i>{{ $bringItem }}</span>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </section>
@endif
