<?php

// General helpers
