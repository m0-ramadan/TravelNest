<?php

// app/Http/Resources/SliderResource.php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SliderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
             'id' => $this->id,
            'image' => 'https://oya-ly.com/'.$this->image,
            'item_order' => $this->item_order,
        ];
    }
}
