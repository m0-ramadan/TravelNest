<?php

namespace App\Http\Requests\Admin\Slider;

use Illuminate\Foundation\Http\FormRequest;

class CreateSliderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'image' =>'required',
            'type' => 'required|boolean',
            'item_order' => 'required',
        ];
    }
    
    public function prepareForValidation ()
    {
        $this->merge([
            'status' => $this->status == 'on',
        ]);
    }
}
