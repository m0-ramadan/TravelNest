<?php

namespace App\Services;

use App\Models\SavvyMedia;
use App\Models\SavvyTourTemplate;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SavvyHostTourTemplateService
{
    public function __construct(
        protected SavvyHostClient $client
    ) {}

    /**
     * Sync all AI Tour Templates from SavvyHost API.
     *
     * @param string $processUuid Process identifier for scoping Cache progress
     * @param int|string|null $adminId Admin ID for scoping Cache progress
     * @return array
     * @throws Exception
     */
    public function syncAll(string $processUuid = 'default', int|string|null $adminId = null): array
    {
        $cacheKey = $this->getProgressCacheKey($processUuid, $adminId);

        $currentPage = 1;
        $lastPage = 1;
        $totalProcessed = 0;
        $errorCount = 0;
        $apiTotal = 0;
        $now = now();

        $this->updateProgress($cacheKey, [
            'status' => 'running',
            'processed' => 0,
            'total' => 0,
            'percentage' => 0,
            'current_page' => 1,
            'last_page' => 1,
            'current_template' => '',
            'message' => 'Connecting to server and fetching tour list...',
            'errors' => 0,
        ]);

        do {
            try {
                $response = $this->client->get('/api/v1/dashboard/ai/templates', [
                    'per_page' => 50,
                    'page' => $currentPage,
                    'is_active' => true,
                ]);
            } catch (Exception $e) {
                Log::error('SavvyHost Templates API connection error', [
                    'page' => $currentPage,
                    'error' => $e->getMessage(),
                ]);
                $this->updateProgress($cacheKey, [
                    'status' => 'failed',
                    'message' => "Server connection error on page {$currentPage}: " . $e->getMessage(),
                ]);
                throw new Exception("Failed to connect to SavvyHost Templates API at page {$currentPage}: " . $e->getMessage());
            }

            if (!$response->successful()) {
                $statusCode = $response->status();
                Log::error('SavvyHost Templates API request failed', [
                    'status' => $statusCode,
                    'page' => $currentPage,
                    'body' => $response->body(),
                ]);

                if ($statusCode === 403) {
                    throw new Exception('SavvyHost API access forbidden (HTTP 403). Please check tenant subdomain configuration.');
                }

                throw new Exception("SavvyHost Templates API returned HTTP status {$statusCode} on page {$currentPage}.");
            }

            $json = $response->json();
            if (!is_array($json)) {
                throw new Exception("Invalid JSON response from SavvyHost Templates API on page {$currentPage}.");
            }

            $data = $json['data'] ?? [];
            $meta = $json['meta'] ?? [];

            // If $data is a single associative object instead of a list of objects, wrap it
            if (is_array($data) && (isset($data['id']) || isset($data['remote_id']) || isset($data['slug']))) {
                $data = [$data];
            }

            $lastPage = (int) ($meta['last_page'] ?? 1);
            $apiTotal = (int) ($meta['total'] ?? count((array) $data));

            if (empty($data) || !is_array($data)) {
                break;
            }

            foreach ($data as $item) {
                if (!is_array($item)) {
                    if (is_numeric($item) || is_string($item)) {
                        $item = ['id' => (string) $item];
                    } else {
                        continue;
                    }
                }

                try {
                    $template = $this->syncTemplate($item, $now);
                    $totalProcessed++;

                    $templateName = $template->display_name;
                    $percentage = $apiTotal > 0 ? min(100, round(($totalProcessed / $apiTotal) * 100, 1)) : 0;

                    $this->updateProgress($cacheKey, [
                        'status' => 'running',
                        'processed' => $totalProcessed,
                        'total' => $apiTotal,
                        'percentage' => $percentage,
                        'current_page' => $currentPage,
                        'last_page' => $lastPage,
                        'current_template' => $templateName,
                        'message' => "Syncing tours... ({$totalProcessed} of {$apiTotal})",
                        'errors' => $errorCount,
                    ]);
                } catch (Exception $e) {
                    $errorCount++;
                    Log::warning('Error syncing template record', [
                        'remote_id' => is_array($item) ? ($item['id'] ?? null) : $item,
                        'error' => $e->getMessage(),
                    ]);
                }
            }

            $currentPage++;
        } while ($currentPage <= $lastPage);

        // Mark missing records from last sync
        SavvyTourTemplate::query()
            ->where('last_synced_at', '<', $now)
            ->update(['missing_from_last_sync' => true]);

        $this->updateProgress($cacheKey, [
            'status' => 'completed',
            'processed' => $totalProcessed,
            'total' => $apiTotal,
            'percentage' => 100,
            'current_page' => $lastPage,
            'last_page' => $lastPage,
            'current_template' => '',
            'message' => 'Synchronization completed successfully!',
            'errors' => $errorCount,
        ]);

        return [
            'total_processed' => $totalProcessed,
            'api_total' => $apiTotal,
            'last_page' => $lastPage,
            'errors' => $errorCount,
        ];
    }

    /**
     * Upsert a single remote template payload into local DB.
     */
    public function syncTemplate(array $remoteData, ?Carbon $now = null): SavvyTourTemplate
    {
        $now = $now ?? now();
        $normalized = $this->normalizeRemoteTemplate($remoteData);

        $remoteId = (string) ($remoteData['id'] ?? $remoteData['remote_id'] ?? '');
        if (empty($remoteId)) {
            throw new Exception('Missing remote_id in template item payload.');
        }

        // Try matching preview media from local SavvyMedia
        $previewMediaId = $this->resolvePreviewMediaId($normalized);

        $template = SavvyTourTemplate::updateOrCreate(
            ['remote_id' => $remoteId],
            array_merge($normalized, [
                'last_synced_at' => $now,
                'missing_from_last_sync' => false,
                'preview_media_id' => $previewMediaId,
            ])
        );

        return $template;
    }

    /**
     * Normalize remote template API payload into model attribute array.
     */
    public function normalizeRemoteTemplate(array $item): array
    {
        $name = $item['name'] ?? null;
        if (is_string($name)) {
            $name = ['en' => $name, 'ar' => $name];
        }

        $description = $item['description'] ?? null;
        if (is_string($description)) {
            $description = ['en' => $description, 'ar' => $description];
        }

        $remoteCreatedAt = null;
        if (!empty($item['created_at'])) {
            try {
                $remoteCreatedAt = Carbon::parse($item['created_at']);
            } catch (Exception $e) {
                $remoteCreatedAt = null;
            }
        }

        $remoteUpdatedAt = null;
        if (!empty($item['updated_at'])) {
            try {
                $remoteUpdatedAt = Carbon::parse($item['updated_at']);
            } catch (Exception $e) {
                $remoteUpdatedAt = null;
            }
        }

        return [
            'remote_slug' => $item['slug'] ?? $item['remote_slug'] ?? null,
            'name' => is_array($name) ? $name : null,
            'description' => is_array($description) ? json_encode($description, JSON_UNESCAPED_UNICODE) : (string) $description,
            'remote_tour_type' => $item['tour_type'] ?? $item['remote_tour_type'] ?? null,
            'remote_category' => $item['category'] ?? $item['remote_category'] ?? null,
            'region' => $item['region'] ?? null,
            'destinations' => is_array($item['destinations'] ?? null) ? $item['destinations'] : [],
            'cities' => is_array($item['cities'] ?? null) ? $item['cities'] : [],
            'vessel_classes' => is_array($item['vessel_classes'] ?? null) ? $item['vessel_classes'] : [],
            'default_ship_slug' => $item['default_ship_slug'] ?? null,
            'duration_value' => isset($item['duration_value']) ? (int) $item['duration_value'] : (isset($item['duration']) ? (int) $item['duration'] : null),
            'duration_unit' => $item['duration_unit'] ?? 'days',
            'description_template' => $item['description_template'] ?? null,
            'highlights' => is_array($item['highlights'] ?? null) ? $item['highlights'] : [],
            'itinerary_outline' => is_array($item['itinerary_outline'] ?? null) ? $item['itinerary_outline'] : [],
            'includes' => is_array($item['includes'] ?? null) ? $item['includes'] : [],
            'excludes' => is_array($item['excludes'] ?? null) ? $item['excludes'] : [],
            'ai_prompt_template' => $item['ai_prompt_template'] ?? null,
            'ai_config' => is_array($item['ai_config'] ?? null) ? $item['ai_config'] : [],
            'customization_options' => is_array($item['customization_options'] ?? null) ? $item['customization_options'] : [],
            'suggested_min_price' => isset($item['suggested_min_price']) ? (float) $item['suggested_min_price'] : null,
            'suggested_max_price' => isset($item['suggested_max_price']) ? (float) $item['suggested_max_price'] : null,
            'price_currency' => $item['price_currency'] ?? 'USD',
            'min_participants' => isset($item['min_participants']) ? (int) $item['min_participants'] : 1,
            'max_participants' => isset($item['max_participants']) ? (int) $item['max_participants'] : null,
            'difficulty_level' => $item['difficulty_level'] ?? null,
            'tags' => is_array($item['tags'] ?? null) ? $item['tags'] : [],
            'generation_count' => isset($item['generation_count']) ? (int) $item['generation_count'] : 0,
            'popularity_score' => isset($item['popularity_score']) ? (float) $item['popularity_score'] : 0.0,
            'remote_is_active' => isset($item['is_active']) ? (bool) $item['is_active'] : true,
            'remote_is_featured' => isset($item['is_featured']) ? (bool) $item['is_featured'] : false,
            'remote_sort_order' => isset($item['sort_order']) ? (int) $item['sort_order'] : 0,
            'allowed_plans' => is_array($item['allowed_plans'] ?? null) ? $item['allowed_plans'] : [],
            'remote_created_at' => $remoteCreatedAt,
            'remote_updated_at' => $remoteUpdatedAt,
            'raw_payload' => $item,
        ];
    }

    /**
     * Get Cache key for sync progress.
     */
    public function getProgressCacheKey(string $processUuid, int|string|null $adminId = null): string
    {
        $adminId = $adminId ?: (auth('admin')->id() ?? 'guest');
        return "savvy_tour_sync_progress:{$adminId}:{$processUuid}";
    }

    /**
     * Update progress in Cache.
     */
    protected function updateProgress(string $cacheKey, array $data): void
    {
        $existing = Cache::get($cacheKey, []);
        Cache::put($cacheKey, array_merge($existing, $data), 600);
    }

    /**
     * Resolve preview media ID from SavvyMedia.
     */
    protected function resolvePreviewMediaId(array $normalized): ?int
    {
        $cities = $normalized['cities'] ?? [];
        $citySlug = !empty($cities[0]) ? strtolower(trim($cities[0])) : null;

        if ($citySlug) {
            $media = SavvyMedia::query()
                ->where('city_slug', $citySlug)
                ->orderByDesc('is_downloaded')
                ->first();

            if ($media) {
                return $media->id;
            }
        }

        return SavvyMedia::query()->orderByDesc('is_downloaded')->first()?->id;
    }
}
